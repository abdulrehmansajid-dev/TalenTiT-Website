Partner logos for TalenTiT website
All files: 512x512 PNG, transparent background, logo centered.

Trademark notice: logos belong to their respective owners.
Confirm permission before public commercial use.

Included:
01_air_university.png — Air University
02_nayatel.png — Nayatel
03_ctg.png — China Three Gorges Corporation (CTG)
04_paf.png — Pakistan Air Force (PAF)
05_abnlp.png — ABNLP (American Board of NLP)
06_tlta.png — Time Line Therapy Association (TLTA)
07_abnlp_coaching.png — Coaching Division of The American Board of NLP
08_wah_medical_college.png — Wah Medical College
09_army_medical_college.png — Army Medical College (AMC)
10_hubco_laraib.png — HUBCO / Laraib Energy Ltd
11_fast_nuces.png — FAST / NUCES
12_wapda.png — WAPDA
13_nust.png — NUST
14_iest.png — IEST (Air University)
15_pide.png — PIDE
16_pips.png — PIPS
17_shifa.png — Shifa International Hospitals Ltd.
18_telenor.png — Telenor
19_sp_global.png — S&P Global
20_comsats.png — COMSATS University Islamabad
21_aghosh.png — Aghosh (Alkhidmat Foundation)

Notes:
- 14_iest uses the Air University logo (IEST is under AU).
- 21_aghosh uses Alkhidmat Foundation branding (Aghosh is an Alkhidmat program).
- 07_abnlp_coaching uses the ABNLP mark (separate coaching logo unavailable).
